# Movie World

Admin uploads movies (poster, story, genres, duration, rating, release date, language, cast, 480p/720p/1080p files). Visitors browse posters, open a movie and download.

## Run on your computer

1. Install Node.js 18 or newer
2. In this folder run `npm install`
3. Start with your first admin password (you can change it later inside the admin panel):
   - Mac/Linux: `ADMIN_PASS=MySecret123 npm start`
   - Windows (cmd): `set ADMIN_PASS=MySecret123 && npm start`
4. Open http://localhost:3000 and click **Admin** to log in

## Hidden admin panel

The public website has no Admin button. Admin login opens only on a secret address:

`http://localhost:3000/<secret-path>`

The path is printed in the terminal every time the server starts and is saved in `movie-world-data/admin-path.txt`. To choose your own, start with `ADMIN_PATH=mySecretWord`. Keep the link private; the password is still required to log in.

## Changing the admin password

Log in, then press **Change password** at the top. You need the current password; the new one must be at least 8 characters. Every other logged-in session is signed out. The new password is saved (hashed) in `movie-world-data/admin.json`, and after that `ADMIN_PASS` is ignored.

Forgot the password? Stop the server, delete `movie-world-data/admin.json`, then start again with `ADMIN_PASS=newPassword`.

## Categories

The home page shows category tabs: Bollywood Movies, South Movies, Hollywood Movies, Web Series, Marvel Movies, Animation Movies. When you upload or edit a movie, tick one or more categories in the form; the movie then appears in that tab (and always under All). A tab is shown once at least one visible movie is in it.

To add your own (for example Gujarati Movies) or remove one, open **Manage categories** at the top of the admin movie list. Removing a category does not delete any movie, it is only taken out of that category. Categories are saved in `movie-world-data/categories.json`.

## Admin features

- Upload and edit movies, with poster, cast photos, genres, rating, language and quality files
- **Screenshots:** add up to 10 scene images per movie in the form (you can remove or add more when editing). They show as a gallery in the movie detail; visitors tap one to open it full size and swipe or use the arrows to browse
- **Search suggestions:** as visitors type in the search box, matching movie names appear below it; clicking one opens that movie (arrow keys and Enter also work)
- **Live chat:** a **Live chat** button at the bottom-right of the website opens a public chat room. A visitor enters a name (2 to 20 letters or numbers, names containing admin, moderator or owner are not allowed), then types messages. Everyone on the site sees every message with the sender's name, and your replies show with an **ADMIN** badge. While you are logged in, the same chat button lets you reply as Admin, delete any message (✕), clear the whole chat, and turn the chat off or on for visitors. Visitors can send at most 10 messages a minute. Messages are saved in `movie-world-data/chat.json` (the last 500 are kept)
- **Direct movie links and Share:** every movie has its own address, `https://yourdomain.com/movie/<id>`. Opening a movie puts that address in the browser bar, and the **Share** button in the movie page gives a copy box plus WhatsApp and Telegram buttons (and the phone's own share sheet). Anyone who opens the link lands straight on that movie
- **Link previews (WhatsApp, Facebook, Telegram, Google):** when a movie link is shared, the server adds the movie's title, story and poster to the page so the chat shows a proper preview card. Movies without a poster use `public/og-default.png`. `/sitemap.xml` and `/robots.txt` help Google find the movie pages. Set `SITE_URL=https://yourdomain.com` when you start the server so the preview links always use your real address
- **Dark mode button:** the moon or sun button at the top switches light and dark mode and remembers the choice on that device
- **Recently viewed:** the home page shows a row of the movies a visitor opened last (kept only on their own device, with a Clear button)
- **Movie requests:** visitors tap **Request a movie** (below the movie list, or in the search box when nothing matches) and fill a short form. In the admin panel, **Movie requests** lists them; the same title asked again is counted (for example "×3 requests") so you can see what is wanted most. Mark a request as added or delete it. Visitors can send at most 5 requests per 10 minutes. Requests are saved in `movie-world-data/requests.json`
- **Web series (seasons and episodes):** in the form, set **Type** to Web series. Add seasons, and in each season add episodes with an optional title, an optional length and 480p, 720p and 1080p files (at least one per episode). Episodes can be removed, and each file can be replaced later when you edit. On the website a series shows a SERIES badge, season tabs and an episode list where every episode has its own download buttons. A title is either a movie or a series: switching the type and saving deletes the files of the old type
- **Cast click:** tap an actor in a movie's Cast to see a popup with just their photo and name
- **Announcement banner:** in the admin panel open **Announcement banner**, write a short message (up to 200 characters), optionally add a link and choose a colour (blue, amber or green), then press **Save and show**. It appears in a bar at the very top of the website for everyone. The message scrolls across the bar like a news ticker (it pauses when the mouse is over it, and stays still for people who turned on "reduce motion"). There is no close button, so it stays until you press **Remove**. **Remove** takes it down
- **Backups:** the server makes a backup of the movie list, categories, requests and announcement by itself every day (files in `movie-world-data/backups/`, the newest 30 are kept). In the admin panel, **Backups** has **Download backup now** (a fresh copy straight to your computer), **Save a copy on the server**, and a list of earlier backups you can download. Movie files and images are not inside these backups; DEPLOY.md shows how to copy them too
- **Movie page layout:** the page has a hero with the poster, title, rating and tags (plus a **Watch trailer** button when a trailer is set), then the storyline and cast on the left with the details card on the right (screenshots come after the storyline), then the **Download** section (SD, HD or Full HD rows with the file size; for a web series the episodes list), and last the **More movies** list. On phones the order is storyline, details, screenshots, cast, download, more movies
- **Downloaded tick:** after a visitor downloads a quality (or an episode), a green tick and "Downloaded" shows on it the next time they open the page. A series shows "2 of 5 downloaded". This is remembered only on that visitor's own device, and a **Clear** link removes it
- **Coming Soon:** set Status to Coming Soon in the form. The movie shows on the website with a COMING SOON badge, its release date and a big Coming Soon box with a day countdown in the detail; a Coming Soon tab appears on the home page. The movie file is optional, and downloads stay off (also on the server) until you set Status back to Released
- **Genres:** click the Genres field to open a popup and tick as many genres as you like (Action, Crime, Adventure, Romance, Comedy, Drama, Thriller, Horror, Mystery, Sci-Fi, Fantasy, Animation, Family, Documentary, Biography, History, War, Western, Musical, Sports, Suspense). Visitors can also filter the home page by several genres at once from the same kind of popup
- **Quality / Release type** (HD, WEB-DL, HD-RIP, WEB-RIP, BluRay, 4K): pick one in the form; it shows as a small badge on the movie card and in the movie detail
- **Trending:** tick Trending in the form, or press the Trend button next to a movie in the list, to show it in the top banner (up to 5). If no movie is marked Trending, the top rated movies show instead. The banner slides by itself every few seconds and visitors can also swipe it, use the arrows or dots, or use the keyboard arrow keys; auto-sliding pauses for a while once someone interacts with it
- **Hidden (draft):** hide a movie from the website without deleting it, then show it again with one click
- **Trailer:** give either a trailer link or upload a trailer video (only one of the two works at a time). An uploaded video plays on the website; a link opens directly on the linked site or app (for example YouTube)
- Search your uploaded movies, with live counts of live, hidden and trending movies and total downloads

## Folder layout

```
movie-world/          the website code (safe to replace on every upgrade)
  server.js
  public/index.html
movie-world-data/     your movies, created automatically NEXT TO the code folder
  movies.json         the movie list (movies.json.bak is a safety copy)
  images/             posters and cast photos
  movies/             the movie files
```

Your movies are stored in `movie-world-data/`, outside the code folder. To store them somewhere else (for example a mounted disk on a server), set `DATA_DIR=/path/to/folder`.

## Upgrading the website without losing movies

- Replace only `server.js` and `public/index.html` (and `package.json` if it changed). Never delete or overwrite `movie-world-data/`.
- Do not deploy by deleting the whole folder and uploading it again unless `movie-world-data/` is kept somewhere else.
- On hosts with a temporary disk (Render free, Heroku, Vercel and similar) every deploy wipes uploaded files. Use a VPS, or attach a persistent disk and set `DATA_DIR` to it.
- If you used an older version that stored movies in `movie-world/data/`, the first start of this version copies them into `movie-world-data/` automatically.
- Back up `movie-world-data/` regularly.

## Going live

- Use a VPS (DigitalOcean, Hetzner, AWS Lightsail) or a host with a persistent disk (Railway, Render with disk). Free hosts that wipe the disk will delete your movies.
- Put the site behind **HTTPS** (Caddy or nginx with Let's Encrypt). Without HTTPS the admin password travels unencrypted.
- Set a strong `ADMIN_PASS`. Optional: `PORT` (default 3000) and `MAX_MB` (max size per movie file, default 4096).
- If you use nginx, set `client_max_body_size 5g;` so large uploads are not blocked.
- For many visitors or very large files, move movie files to object storage (S3, Cloudflare R2).

## Allowed files

- Movies: mp4, webm, mkv, avi, mov, m4v
- Posters and cast photos: jpg, png, webp, gif

## Important

Upload only movies you own or have the rights to share (your own films, licensed or public domain). Hosting copyrighted movies without permission is illegal and can get the site taken down.
