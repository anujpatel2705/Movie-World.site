# Run Movie World in VS Code

## One time
1. Install **Node.js** (version 18 or newer) from https://nodejs.org
2. In VS Code choose **File > Open Folder** and open this `movie-world` folder
3. Open the terminal in VS Code (**Terminal > New Terminal**) and run:

   ```
   npm install
   ```

## Start the website
- Press **F5** (or open **Run and Debug** and press **Run Movie World**), or
- In the terminal run:
  - Windows (cmd): `set ADMIN_PASS=ChangeMe123 && npm start`
  - Windows (PowerShell): `$env:ADMIN_PASS="ChangeMe123"; npm start`
  - Mac or Linux: `ADMIN_PASS=ChangeMe123 npm start`

Then open http://localhost:3000 in your browser.

## Admin panel
The admin panel is hidden. When the server starts, the terminal prints a line like

`Admin login page (keep private): http://localhost:3000/m-1a2b3c4d5e6f`

Open that address and log in with the password (`ChangeMe123` the first time). Press **Change password** at the top to set your own. After you change it, the `ADMIN_PASS` setting is ignored.

## Where your movies are saved
In a folder called `movie-world-data` created **next to** this project folder (not inside it), so updating the code never deletes your movies.

## Good to know
- `public/index.html` is the whole website (design and behaviour). `server.js` is the server. Edit, save, then stop and start the server again (the server must be restarted for `server.js` changes; for `index.html` only refresh the browser).
- Change the default password in `.vscode/launch.json` before sharing your screen or code.
- To put the site on the internet, follow `DEPLOY.md`. Features and settings are explained in `README.md`.
- Upload only movies you own or have the rights to share.
