# Put Movie World online (so every visitor sees your movies)

Visitors see what you upload only when the website runs on a server that stays on 24/7. The chat preview cannot do this. Follow these steps on a VPS (any provider with Ubuntu 22.04 or 24.04, for example Hetzner, DigitalOcean, Oracle Cloud free tier, AWS Lightsail). Choose a plan with enough disk for your movies.

You also need a domain name pointed to the server's IP address (an "A record"). A domain is needed for HTTPS, and HTTPS is needed so the admin password is encrypted.

## 1. Install Node.js on the server

```
ssh youruser@SERVER_IP
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs nginx
sudo npm install -g pm2
```

## 2. Copy the website

On your own computer, from the folder that contains `movie-world`:

```
scp -r movie-world youruser@SERVER_IP:~/
```

On the server:

```
cd ~/movie-world
npm install --omit=dev
sudo mkdir -p /var/movie-world-data
sudo chown $USER /var/movie-world-data
```

## 3. Start it (and keep it running after reboot)

```
ADMIN_PASS='ChooseAStrongPassword' DATA_DIR=/var/movie-world-data TRUST_PROXY=1 SITE_URL=https://yourdomain.com pm2 start server.js --name movie-world
pm2 save
pm2 startup
```

`pm2 startup` prints one more command. Copy it and run it.

Find your secret admin page address:

```
pm2 logs movie-world --lines 20
```

Look for the line `Admin login page (keep private)`. Only the part after the last `/` matters; on your live site the address is `https://yourdomain.com/<that part>`.

## 4. Connect your domain with HTTPS

Create the file `/etc/nginx/sites-available/movie-world` (use `sudo nano`):

```
server {
    server_name yourdomain.com;
    client_max_body_size 5g;
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_request_buffering off;
        proxy_read_timeout 3600s;
        proxy_send_timeout 3600s;
    }
}
```

Then:

```
sudo ln -s /etc/nginx/sites-available/movie-world /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
sudo ufw allow OpenSSH && sudo ufw allow 'Nginx Full' && sudo ufw enable
```

Open `https://yourdomain.com`. Anyone who opens this address sees the movies you upload, and every change you make in the admin panel shows for everybody right away.

## Check the link preview

After the site is live, paste a movie link (for example `https://yourdomain.com/movie/<id>`) into WhatsApp or Telegram to see the preview card. Facebook's Sharing Debugger shows what a chat app reads from the page. If the preview looks old after you change a movie, the chat app has cached it; send the link again with `?v=2` at the end.

## Backups and restoring

**What is backed up by itself:** every day the server saves a backup file of the movie list, categories, visitor requests and announcement into `/var/movie-world-data/backups/` and keeps the newest 30. You can also download a backup from the admin panel (**Backups**).

**What is not inside those backups:** the movie files and images (folders `movies/` and `images/` inside the data folder). They are large, so copy them separately. The simplest way is your hosting company's disk snapshot. Or copy them to another computer with rsync, for example from that computer:

```
rsync -a youruser@SERVER_IP:/var/movie-world-data/ ~/movie-world-backup/
```

Run it from a scheduled task (cron) so it happens every night. The movie list is only useful together with its files.

**Restoring the movie list from a backup file** (for example `backup-2026-10-11.json`):

```
pm2 stop movie-world
node -e "const fs=require('fs');const b=JSON.parse(fs.readFileSync('backup-2026-10-11.json'));const d='/var/movie-world-data/';fs.writeFileSync(d+'movies.json',JSON.stringify(b.movies,null,2));fs.writeFileSync(d+'categories.json',JSON.stringify(b.categories,null,2));fs.writeFileSync(d+'requests.json',JSON.stringify(b.requests,null,2));if(b.announcement)fs.writeFileSync(d+'announcement.json',JSON.stringify(b.announcement,null,2))"
pm2 start movie-world
```

The movie files must still be in `movies/` and `images/` for the restored movies to work.

## Updating the website later

Copy the new `server.js` and `public/index.html` to the server, then:

```
pm2 restart movie-world
```

Your movies stay safe in `/var/movie-world-data`. Back this folder up regularly.

## Only upload movies you have rights to

Upload only movies you own or are allowed to share (your own films, licensed or public domain). Hosting copyrighted movies without permission is illegal and the hosting company can shut your server down.
