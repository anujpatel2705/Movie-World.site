const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const ADMIN_PASS = process.env.ADMIN_PASS;
const MAX_MB = Number(process.env.MAX_MB) || 4096; // max size per movie file

// Movies live OUTSIDE the project folder by default, so replacing/updating the
// code never deletes them. Override with DATA_DIR=/some/permanent/folder
const DATA = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(__dirname, '..', 'movie-world-data');
const OLD = path.join(__dirname, 'data'); // older versions stored data here
if (!fs.existsSync(DATA) && fs.existsSync(OLD)) {
  try { fs.cpSync(OLD, DATA, { recursive: true }); console.log('Copied existing movies from ' + OLD + ' to ' + DATA); }
  catch (e) { console.error('Could not copy old data:', e.message); }
}
const IMG = path.join(DATA, 'images');
const VID = path.join(DATA, 'movies');
const DB = path.join(DATA, 'movies.json');
[IMG, VID].forEach((d) => fs.mkdirSync(d, { recursive: true }));

// ADMIN_PASS is only the FIRST password. After you change it in the admin panel,
// the new one is saved (hashed) in admin.json and ADMIN_PASS is ignored.
const CRED_FILE = path.join(DATA, 'admin.json');
if (!ADMIN_PASS && !fs.existsSync(CRED_FILE)) {
  console.error('Set an admin password first, e.g.  ADMIN_PASS=mySecret123 npm start');
  process.exit(1);
}
const hashPw = (pw, salt) => crypto.scryptSync(String(pw), salt, 64);
function checkPw(pw) {
  if (typeof pw !== 'string' || pw.length > 200) return false;
  try {
    const c = JSON.parse(fs.readFileSync(CRED_FILE, 'utf8'));
    return crypto.timingSafeEqual(hashPw(pw, c.salt), Buffer.from(c.hash, 'hex'));
  } catch (e) {
    if (fs.existsSync(CRED_FILE)) return false; // unreadable file: never fall back silently
    return same(pw, ADMIN_PASS);
  }
}

// Secret admin page address. Set ADMIN_PATH=yourSecretWord to choose it yourself,
// otherwise a random one is created once and saved in the data folder.
const ADMIN_PATH_FILE = path.join(DATA, 'admin-path.txt');
let ADMIN_PATH = (process.env.ADMIN_PATH || '').replace(/[^\w-]/g, '');
if (!ADMIN_PATH) {
  try { ADMIN_PATH = fs.readFileSync(ADMIN_PATH_FILE, 'utf8').trim(); } catch (e) { /* first run */ }
  if (!ADMIN_PATH) {
    ADMIN_PATH = 'm-' + crypto.randomBytes(6).toString('hex');
    fs.writeFileSync(ADMIN_PATH_FILE, ADMIN_PATH);
  }
}

const FIELD = { f480: '480p', f720: '720p', f1080: '1080p' };
const QUALS = Object.values(FIELD);
// episode files arrive as ep_<key>_<quality>; everything that is a video goes to the movies folder
const isVidField = (n) => !!FIELD[n] || n === 'tfile' || /^ep_[A-Za-z0-9]+_(480p|720p|1080p)$/.test(n);
const IMG_EXT = ['.jpg', '.jpeg', '.png', '.webp', '.gif'];
const RELS = ['HD', 'WEB-DL', 'HD-RIP', 'WEB-RIP', 'BluRay', '4K']; // movie quality / release type options
const VID_EXT = ['.mp4', '.webm', '.mkv', '.avi', '.mov', '.m4v'];

const rid = () => crypto.randomBytes(8).toString('hex');

// Website categories (Bollywood, South, Web Series ...). The admin can add or remove them.
const CATS_FILE = path.join(DATA, 'categories.json');
const DEFAULT_CATS = ['Bollywood Movies', 'South Movies', 'Hollywood Movies', 'Web Series', 'Marvel Movies', 'Animation Movies'];
const loadCats = () => {
  try { const c = JSON.parse(fs.readFileSync(CATS_FILE, 'utf8')); if (Array.isArray(c)) return c; } catch (e) { /* use defaults */ }
  return DEFAULT_CATS.slice();
};
const saveCats = (c) => fs.writeFileSync(CATS_FILE, JSON.stringify(c, null, 2));
const load = () => {
  for (const f of [DB, DB + '.bak']) {
    try { if (fs.existsSync(f)) return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { /* try backup */ }
  }
  return [];
};
const save = (m) => {
  if (fs.existsSync(DB)) fs.copyFileSync(DB, DB + '.bak'); // keep the previous list as a safety copy
  fs.writeFileSync(DB + '.tmp', JSON.stringify(m, null, 2));
  fs.renameSync(DB + '.tmp', DB);
};
const rm = (dir, name) => name && fs.unlink(path.join(dir, path.basename(name)), () => {});
const fmtSize = (b) => (b >= 1e9 ? (b / 1e9).toFixed(1) + ' GB' : Math.max(1, Math.round(b / 1e6)) + ' MB');

// ---------- admin sessions + login rate limit ----------
const sessions = new Map(); // token -> expiry
const tries = new Map(); // ip -> {n, t}
const limited = (ip) => {
  const t = tries.get(ip) || { n: 0, t: Date.now() };
  if (Date.now() - t.t > 15 * 60e3) { t.n = 0; t.t = Date.now(); }
  t.n++;
  tries.set(ip, t);
  return t.n > 10;
};
const same = (a, b) => {
  const x = crypto.createHash('sha256').update(String(a)).digest();
  const y = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(x, y);
};
const auth = (req, res, next) => {
  const exp = sessions.get(req.headers['x-token']);
  if (exp && exp > Date.now()) return next();
  res.status(401).json({ error: 'Please log in again as admin' });
};

// ---------- uploads ----------
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, f, cb) => cb(null, isVidField(f.fieldname) ? VID : IMG),
    filename: (req, f, cb) => cb(null, rid() + path.extname(f.originalname).toLowerCase()),
  }),
  fileFilter: (req, f, cb) => {
    const ext = path.extname(f.originalname).toLowerCase();
    const ok = isVidField(f.fieldname) ? VID_EXT.includes(ext) : IMG_EXT.includes(ext);
    cb(ok ? null : new Error('File type not allowed: ' + f.originalname), ok);
  },
  limits: { fileSize: MAX_MB * 1024 * 1024, files: 300 },
}).any();
const takeUpload = (req, res, next) =>
  upload(req, res, (err) => (err ? res.status(400).json({ error: err.message }) : next()));
const dropFiles = (req) => (req.files || []).forEach((f) => fs.unlink(f.path, () => {}));

// ---------- validation ----------
function parse(body) {
  let d;
  try { d = JSON.parse(body.data); } catch { throw new Error('Bad form data'); }
  const s = (v, max) => (typeof v === 'string' && v.trim() && v.length <= max ? v.trim() : null);
  const known = loadCats();
  const out = {
    t: s(d.t, 200),
    g: Array.isArray(d.g) ? d.g.filter((x) => typeof x === 'string' && x.length < 40).slice(0, 20) : [],
    h: Number(d.h),
    rt: Number(d.rt),
    r: /^\d{4}-\d{2}-\d{2}$/.test(d.r) ? d.r : null,
    d: s(d.d, 200000),
    lang: s(d.lang, 40) || 'Other',
    trailer: typeof d.trailer === 'string' && /^https?:\/\/\S{1,500}$/i.test(d.trailer.trim()) ? d.trailer.trim() : '',
    cat: Array.isArray(d.cat) ? d.cat.filter((c) => known.includes(c)).slice(0, 20) : [],
    rel: RELS.includes(d.rel) ? d.rel : '',
    soon: d.soon === true,
    kind: d.kind === 'series' ? 'series' : '',
    feat: d.feat === true,
    hid: d.hid === true,
    c: Array.isArray(d.c)
      ? d.c.slice(0, 50).filter((c) => s(c && c.n, 100)).map((c) => ({
          n: c.n.trim(),
          p: typeof c.p === 'string' && c.p.startsWith('/img/') ? c.p : '',
        }))
      : [],
  };
  if (!out.t) throw new Error('Title is required');
  if (!out.g.length) throw new Error('Select at least one genre');
  if (!(out.h > 0 && out.h <= 12)) throw new Error('Duration must be between 0 and 12 hours');
  if (!(out.rt >= 0 && out.rt <= 10)) throw new Error('Rating must be 0 to 10');
  if (!out.r) throw new Error('Release date is required');
  if (!out.d) throw new Error('Story is required');
  if (out.d.split('\n').length > 1000) throw new Error('Story is over 1000 lines');
  return out;
}

function applyFiles(movie, req) {
  const old = [];
  for (const f of req.files || []) {
    if (FIELD[f.fieldname]) {
      const q = FIELD[f.fieldname];
      if (movie.files[q]) old.push([VID, movie.files[q].file]);
      movie.files[q] = { file: f.filename, s: fmtSize(f.size), ext: path.extname(f.filename) };
    } else if (f.fieldname === 'tfile') {
      if (movie.tvideo) old.push([VID, movie.tvideo.file]);
      movie.tvideo = { file: f.filename, s: fmtSize(f.size), ext: path.extname(f.filename) };
    } else if (f.fieldname === 'poster') {
      if (movie.poster) old.push([IMG, movie.poster]);
      movie.poster = '/img/' + f.filename;
    } else if (/^cast_\d+$/.test(f.fieldname)) {
      const c = movie.c[Number(f.fieldname.slice(5))];
      if (c) c.p = '/img/' + f.filename;
      else fs.unlink(f.path, () => {});
    }
  }
  return old;
}

// Screenshots: the form sends the final ordered list. '/img/..' keeps an existing image,
// '@k' means "the new file uploaded as shot_k". Anything else is ignored.
const shotSpec = (req) => {
  try { const a = JSON.parse(req.body.data).shots; return Array.isArray(a) ? a.filter((x) => typeof x === 'string').slice(0, 10) : null; }
  catch (e) { return null; }
};
function applyShots(m, req, spec) {
  if (!spec) return [];
  const byName = {};
  (req.files || []).forEach((f) => { if (/^shot_\d+$/.test(f.fieldname)) byName[f.fieldname] = f; });
  const prev = m.shots || [];
  const next = [];
  const used = new Set();
  for (const e of spec) {
    if (/^@\d+$/.test(e)) {
      const f = byName['shot_' + e.slice(1)];
      if (f && !used.has(f.fieldname)) { next.push('/img/' + f.filename); used.add(f.fieldname); }
    } else if (e.startsWith('/img/') && prev.includes(e) && !next.includes(e)) next.push(e);
  }
  Object.values(byName).forEach((f) => { if (!used.has(f.fieldname)) fs.unlink(f.path, () => {}); });
  m.shots = next;
  return prev.filter((p) => !next.includes(p)).map((p) => [IMG, p]);
}

// Trailer rule: a movie has EITHER a trailer link OR an uploaded trailer video, never both.
const hasT = (req) => (req.files || []).some((f) => f.fieldname === 'tfile');
const rmFlag = (req) => { try { return JSON.parse(req.body.data).rmtv === true; } catch (e) { return false; } };
function fixTrailer(m, req, rm, old) {
  if (hasT(req)) m.trailer = '';
  else if ((m.trailer || rm) && m.tvideo) { old.push([VID, m.tvideo.file]); m.tvideo = null; }
}

// ---------- web series: seasons and episodes ----------
// movie.seasons = [{ n, eps: [{ id, t, h, files: { '720p': { file, s, ext } } }] }]
const rawData = (req) => { try { return JSON.parse(req.body.data) || {}; } catch (e) { return {}; } };
const strN = (v, n) => (typeof v === 'string' ? v.trim().slice(0, n) : '');
const epFiles = (e) => Object.values(e.files || {});
function applySeries(m, req, d, old) {
  const byKey = {};
  for (const f of req.files || []) {
    const k = f.fieldname.match(/^ep_([A-Za-z0-9]+)_(480p|720p|1080p)$/);
    if (k) (byKey[k[1]] = byKey[k[1]] || {})[k[2]] = f;
  }
  const prev = {};
  (m.seasons || []).forEach((s) => s.eps.forEach((e) => { prev[e.id] = e; }));
  const used = new Set();
  const seasons = [];
  (Array.isArray(d.seasons) ? d.seasons : []).slice(0, 30).forEach((s, si) => {
    const eps = [];
    (Array.isArray(s && s.eps) ? s.eps : []).slice(0, 500).forEach((e) => {
      const p = typeof e.id === 'string' && prev[e.id] ? prev[e.id] : null;
      const ep = p || { id: rid(), files: {} };
      if (p) delete prev[e.id];
      ep.t = strN(e.t, 120);
      ep.h = Number(e.h) > 0 && Number(e.h) <= 12 ? Number(e.h) : 0;
      const nf = byKey[String(e.key)] || {};
      for (const q of QUALS) {
        if (!nf[q]) continue;
        if (ep.files[q]) old.push([VID, ep.files[q].file]);
        ep.files[q] = { file: nf[q].filename, s: fmtSize(nf[q].size), ext: path.extname(nf[q].filename) };
        used.add(nf[q]);
      }
      eps.push(ep);
    });
    seasons.push({ n: si + 1, eps });
  });
  Object.values(prev).forEach((e) => epFiles(e).forEach((f) => old.push([VID, f.file]))); // episodes removed in the form
  (req.files || []).forEach((f) => { if (/^ep_/.test(f.fieldname) && !used.has(f)) fs.unlink(f.path, () => {}); });
  m.seasons = seasons;
}
// A title is EITHER a movie (m.files) OR a web series (m.seasons). Switching type removes the old type's files.
function finishType(m, req, old, noFileMsg) {
  if (m.kind === 'series') {
    Object.values(m.files || {}).forEach((f) => old.push([VID, f.file]));
    m.files = {};
    applySeries(m, req, rawData(req), old);
    if (!m.soon) {
      if (!m.seasons.some((s) => s.eps.length)) throw new Error('Add at least one episode');
      m.seasons.forEach((s) => s.eps.forEach((e, k) => {
        if (!Object.keys(e.files).length) throw new Error('Season ' + s.n + ' episode ' + (k + 1) + ' needs at least one file');
      }));
    }
  } else {
    (m.seasons || []).forEach((s) => s.eps.forEach((e) => epFiles(e).forEach((f) => old.push([VID, f.file]))));
    m.seasons = [];
    (req.files || []).forEach((f) => { if (/^ep_/.test(f.fieldname)) fs.unlink(f.path, () => {}); });
    if (!Object.keys(m.files).length && !m.soon) throw new Error(noFileMsg);
  }
}

const pubFiles = (files) => Object.fromEntries(Object.entries(files || {}).map(([q, f]) => [q, { s: f.s }]));
const pub = (m) => ({
  ...m,
  tvideo: m.tvideo ? { s: m.tvideo.s } : null,
  files: pubFiles(m.files),
  seasons: (m.seasons || []).map((s) => ({ n: s.n, eps: s.eps.map((e) => ({ id: e.id, t: e.t, h: e.h, files: pubFiles(e.files) })) })),
});

// ---------- app ----------
const app = express();
app.disable('x-powered-by');
// Behind nginx/Caddy every request looks like it comes from 127.0.0.1. Set TRUST_PROXY=1 so the
// login rate limit counts each visitor separately instead of locking everyone out together.
if (process.env.TRUST_PROXY) app.set('trust proxy', 1);
app.use((req, res, next) => { res.set('X-Content-Type-Options', 'nosniff'); next(); });
app.use(express.json());
app.use('/img', express.static(IMG, { maxAge: '7d' }));
// ---------- link previews: WhatsApp, Facebook, Telegram and Google ----------
// Chat apps and search engines do not run JavaScript, so the server writes the movie's
// title, story and poster into the page head for every /movie/<id> address.
// Set SITE_URL=https://yourdomain.com so the preview links are always correct.
const SITE_URL = (process.env.SITE_URL || '').replace(/\/+$/, '');
const baseUrl = (req) => SITE_URL || req.protocol + '://' + req.get('host');
const INDEX_FILE = path.join(__dirname, 'public', 'index.html');
const escA = (v) => String(v).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const clip = (v, n) => {
  const t = String(v || '').replace(/\s+/g, ' ').trim();
  return t.length > n ? t.slice(0, n - 1).trimEnd() + '\u2026' : t;
};
const isoDur = (h) => { const m = Math.round(h * 60); return 'PT' + Math.floor(m / 60) + 'H' + (m % 60) + 'M'; };
const HOME_DESC = 'Browse movies by category and genre, watch trailers and download in HD.';
function pageHtml(req, o) {
  const base = baseUrl(req);
  const image = o.image ? base + o.image : base + '/og-default.png';
  const url = base + o.path;
  const tags = [
    '<meta name="description" content="' + escA(o.desc) + '">',
    '<link rel="canonical" href="' + escA(url) + '">',
    '<meta property="og:site_name" content="Movie World">',
    '<meta property="og:type" content="' + (o.type || 'website') + '">',
    '<meta property="og:title" content="' + escA(o.title) + '">',
    '<meta property="og:description" content="' + escA(o.desc) + '">',
    '<meta property="og:url" content="' + escA(url) + '">',
    '<meta property="og:image" content="' + escA(image) + '">',
    '<meta name="twitter:card" content="summary_large_image">',
    '<meta name="twitter:title" content="' + escA(o.title) + '">',
    '<meta name="twitter:description" content="' + escA(o.desc) + '">',
    '<meta name="twitter:image" content="' + escA(image) + '">',
  ];
  if (o.ld) tags.push('<script type="application/ld+json">' + JSON.stringify(Object.assign({ url, image }, o.ld)).replace(/</g, '\\u003c') + '</script>');
  const html = fs.readFileSync(INDEX_FILE, 'utf8').replace(/<title>[\s\S]*?<\/title>/, '<title>' + escA(o.title) + '</title>');
  return html.replace('</head>', tags.join('\n') + '\n</head>');
}

app.get('/', (req, res) => res.type('html').send(pageHtml(req, { title: 'Movie World', desc: HOME_DESC, path: '/' })));

app.get('/movie/:id', (req, res) => {
  const m = load().find((x) => x.id === req.params.id && !x.hid);
  if (!m) return res.status(404).type('html').send(pageHtml(req, { title: 'Movie not found - Movie World', desc: HOME_DESC, path: '/' }));
  const story = clip(m.d, 150);
  const desc = m.soon ? clip('Coming soon, releasing ' + m.r + '. ' + story, 200) : story;
  const title = m.t + (m.r ? ' (' + m.r.slice(0, 4) + ')' : '') + ' - Movie World';
  const ld = { '@context': 'https://schema.org', '@type': m.kind === 'series' ? 'TVSeries' : 'Movie', name: m.t, description: desc, datePublished: m.r, genre: m.g, duration: isoDur(m.h) };
  res.type('html').send(pageHtml(req, { title, desc, image: m.poster, path: '/movie/' + m.id, type: 'video.movie', ld }));
});

app.get('/robots.txt', (req, res) =>
  res.type('text/plain').send('User-agent: *\nAllow: /\nDisallow: /api/\nDisallow: /download/\nDisallow: /trailer/\nSitemap: ' + baseUrl(req) + '/sitemap.xml\n'));

app.get('/sitemap.xml', (req, res) => {
  const base = baseUrl(req);
  const urls = [base + '/'].concat(load().filter((m) => !m.hid).map((m) => base + '/movie/' + m.id));
  res.type('application/xml').send('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' +
    urls.map((u) => '  <url><loc>' + escA(u) + '</loc></url>').join('\n') + '\n</urlset>\n');
});

// Hidden admin entry: only this secret address opens the login box
app.get('/' + ADMIN_PATH, (req, res) => {
  const html = fs.readFileSync(path.join(__dirname, 'public', 'index.html'), 'utf8');
  res.type('html').send(html.replace('</head>', '<script>window.ADMIN_ENTRY=true</script></head>'));
});
app.use(express.static(path.join(__dirname, 'public')));

app.post('/api/login', (req, res) => {
  if (limited(req.ip)) return res.status(429).json({ error: 'Too many attempts. Try again later.' });
  if (!checkPw(req.body && req.body.password)) return res.status(401).json({ error: 'Wrong password' });
  const token = rid() + rid();
  sessions.set(token, Date.now() + 12 * 3600e3);
  res.json({ token });
});

// ---------- announcement banner (one notice shown at the top of the website) ----------
const ANN_FILE = path.join(DATA, 'announcement.json');
let ann = null;
try { const a = JSON.parse(fs.readFileSync(ANN_FILE, 'utf8')); if (a && typeof a.text === 'string') ann = a; } catch (e) { /* none yet */ }
const URL_OK = /^(https?:\/\/\S{1,290}|\/(?!\/)\S{0,290})$/i;
const annPublic = () => (ann && ann.on ? { id: ann.id, text: ann.text, url: ann.url, label: ann.label, style: ann.style } : {});

app.get('/api/announcement', (req, res) => res.json(annPublic()));
app.get('/api/admin/announcement', auth, (req, res) => res.json(ann || {}));

app.put('/api/admin/announcement', auth, (req, res) => {
  const b = req.body || {};
  const text = typeof b.text === 'string' ? b.text.trim().replace(/\s+/g, ' ') : '';
  if (!text || text.length > 200) return res.status(400).json({ error: 'The message must be 1 to 200 characters.' });
  const url = typeof b.url === 'string' ? b.url.trim() : '';
  if (url && !URL_OK.test(url)) return res.status(400).json({ error: 'The link must start with https:// (or / for a page on this site).' });
  ann = {
    id: rid(), // a new id makes the banner show again for people who closed the old one
    text,
    url,
    label: url ? strN(b.label, 30) || 'Learn more' : '',
    style: ['info', 'warn', 'ok'].includes(b.style) ? b.style : 'info',
    on: true,
    ts: new Date().toISOString(),
  };
  fs.writeFileSync(ANN_FILE, JSON.stringify(ann, null, 2));
  res.json(ann);
});

app.delete('/api/admin/announcement', auth, (req, res) => {
  ann = null;
  fs.unlink(ANN_FILE, () => {});
  res.json({ ok: true });
});

// ---------- movie requests from visitors ----------
const REQ_FILE = path.join(DATA, 'requests.json');
const loadReq = () => {
  try { const r = JSON.parse(fs.readFileSync(REQ_FILE, 'utf8')); if (Array.isArray(r)) return r; } catch (e) { /* none yet */ }
  return [];
};
const saveReq = (r) => {
  fs.writeFileSync(REQ_FILE + '.tmp', JSON.stringify(r, null, 2));
  fs.renameSync(REQ_FILE + '.tmp', REQ_FILE);
};
const rqtries = new Map(); // ip -> {n, t}: at most 5 requests per 10 minutes per visitor
const rqlimited = (ip) => {
  const now = Date.now();
  if (rqtries.size > 5000) rqtries.clear();
  const t = rqtries.get(ip) || { n: 0, t: now };
  if (now - t.t > 10 * 60e3) { t.n = 0; t.t = now; }
  t.n++;
  rqtries.set(ip, t);
  return t.n > 5;
};

app.post('/api/requests', (req, res) => {
  if (rqlimited(req.ip)) return res.status(429).json({ error: 'Too many requests. Please try again in a few minutes.' });
  const b = req.body || {};
  if (b.website) return res.json({ ok: true }); // hidden field filled in = bot, ignore silently
  const v = (x, n) => (typeof x === 'string' ? x.trim().replace(/\s+/g, ' ').slice(0, n) : '');
  const title = v(b.t, 100);
  if (title.length < 2) return res.status(400).json({ error: 'Please type the movie name.' });
  const all = loadReq();
  const now = new Date().toISOString();
  const ex = all.find((x) => !x.done && x.t.toLowerCase() === title.toLowerCase());
  if (ex) { // same movie asked again: count it instead of adding a duplicate
    ex.count = (ex.count || 1) + 1;
    ex.ts = now;
    if (!ex.note) ex.note = v(b.note, 300);
  } else {
    all.unshift({ id: rid(), t: title, y: v(b.y, 10), l: v(b.l, 30), n: v(b.n, 40), c: v(b.c, 100), note: v(b.note, 300), ts: now, count: 1, done: false });
  }
  saveReq(all.slice(0, 1000));
  res.json({ ok: true });
});

app.get('/api/admin/requests', auth, (req, res) => res.json(loadReq()));

app.patch('/api/admin/requests/:id', auth, (req, res) => {
  const all = loadReq();
  const r = all.find((x) => x.id === req.params.id);
  if (!r) return res.status(404).json({ error: 'Request not found' });
  if (req.body && typeof req.body.done === 'boolean') r.done = req.body.done;
  saveReq(all);
  res.json(r);
});

app.delete('/api/admin/requests/:id', auth, (req, res) => {
  saveReq(loadReq().filter((x) => x.id !== req.params.id));
  res.json({ ok: true });
});

// ---------- public live chat: everyone on the site sees every message ----------
const CHAT_FILE = path.join(DATA, 'chat.json');
let chat = { on: true, seq: 0, rev: 0, msgs: [] };
try {
  const c = JSON.parse(fs.readFileSync(CHAT_FILE, 'utf8'));
  if (c && Array.isArray(c.msgs)) chat = { on: c.on !== false, seq: c.seq || 0, rev: c.rev || 0, msgs: c.msgs };
} catch (e) { /* no chat yet */ }
const saveChat = () => {
  fs.writeFileSync(CHAT_FILE + '.tmp', JSON.stringify(chat));
  fs.renameSync(CHAT_FILE + '.tmp', CHAT_FILE);
};
const ctries = new Map(); // ip -> send times: at most 10 messages per minute per visitor
const climited = (ip) => {
  const now = Date.now();
  if (ctries.size > 5000) ctries.clear();
  const a = (ctries.get(ip) || []).filter((t) => now - t < 60e3);
  a.push(now);
  ctries.set(ip, a);
  return a.length > 10;
};
const NAME_RE = /^[\p{L}\p{N} ._-]{2,20}$/u;
const addMsg = (name, text, a) => {
  chat.seq++;
  const m = { n: chat.seq, id: rid(), name, text, a, ts: new Date().toISOString() };
  chat.msgs.push(m);
  if (chat.msgs.length > 500) chat.msgs.shift();
  saveChat();
  return m;
};

app.get('/api/chat', (req, res) => {
  const after = Number(req.query.after) || 0;
  const rev = Number(req.query.rev) || 0;
  const full = rev !== chat.rev || after === 0 || after > chat.seq; // client is new, out of date, or ahead
  const msgs = full ? chat.msgs.slice(-100) : chat.msgs.filter((m) => m.n > after).slice(-100);
  res.json({ on: chat.on, last: chat.seq, rev: chat.rev, full, msgs });
});

app.post('/api/chat', (req, res) => {
  if (!chat.on) return res.status(403).json({ error: 'The chat is turned off right now.' });
  if (climited(req.ip)) return res.status(429).json({ error: 'You are sending too fast. Please wait a moment.' });
  const b = req.body || {};
  if (b.website) return res.json({ ok: true }); // hidden field filled in = bot, ignore silently
  const name = typeof b.name === 'string' ? b.name.trim().replace(/\s+/g, ' ') : '';
  if (!NAME_RE.test(name) || /admin|moderator|owner/i.test(name))
    return res.status(400).json({ error: 'Please choose another name (2 to 20 letters or numbers).' });
  const text = typeof b.text === 'string' ? b.text.trim() : '';
  if (!text || text.length > 500) return res.status(400).json({ error: 'Message must be 1 to 500 characters.' });
  res.json({ ok: true, msg: addMsg(name, text, false) });
});

app.post('/api/admin/chat', auth, (req, res) => {
  const text = req.body && typeof req.body.text === 'string' ? req.body.text.trim() : '';
  if (!text || text.length > 500) return res.status(400).json({ error: 'Message must be 1 to 500 characters.' });
  res.json({ ok: true, msg: addMsg('Admin', text, true) }); // only a logged-in admin can post as Admin
});

app.delete('/api/admin/chat/:id', auth, (req, res) => {
  chat.msgs = chat.msgs.filter((m) => m.id !== req.params.id);
  chat.rev++;
  saveChat();
  res.json({ ok: true });
});

app.delete('/api/admin/chat', auth, (req, res) => {
  chat.msgs = [];
  chat.rev++;
  saveChat();
  res.json({ ok: true });
});

app.put('/api/admin/chat/settings', auth, (req, res) => {
  if (!req.body || typeof req.body.on !== 'boolean') return res.status(400).json({ error: 'Invalid setting' });
  chat.on = req.body.on;
  saveChat();
  res.json({ ok: true, on: chat.on });
});

app.get('/api/categories', (req, res) => res.json(loadCats()));

app.put('/api/categories', auth, (req, res) => {
  const raw = req.body && req.body.cats;
  if (!Array.isArray(raw) || raw.length > 30) return res.status(400).json({ error: 'Invalid categories' });
  const list = [];
  for (const c of raw) {
    const n = typeof c === 'string' ? c.trim() : '';
    if (!n || n.length > 40) return res.status(400).json({ error: 'Category names must be 1 to 40 characters' });
    if (list.some((x) => x.toLowerCase() === n.toLowerCase())) return res.status(400).json({ error: 'Duplicate category: ' + n });
    list.push(n);
  }
  saveCats(list);
  const all = load();
  all.forEach((m) => { m.cat = (m.cat || []).filter((c) => list.includes(c)); });
  save(all);
  res.json(list);
});

app.get('/api/movies', (req, res) => res.json(load().filter((m) => !m.hid).map(pub)));
app.post('/api/admin/password', auth, (req, res) => {
  if (limited(req.ip)) return res.status(429).json({ error: 'Too many attempts. Try again later.' });
  const { current, next } = req.body || {};
  if (!checkPw(current)) return res.status(403).json({ error: 'Current password is wrong' });
  if (typeof next !== 'string' || next.length < 8 || next.length > 200)
    return res.status(400).json({ error: 'New password must be at least 8 characters' });
  if (next === current) return res.status(400).json({ error: 'New password must be different' });
  const salt = crypto.randomBytes(16).toString('hex');
  fs.writeFileSync(CRED_FILE + '.tmp', JSON.stringify({ salt, hash: hashPw(next, salt).toString('hex') }));
  fs.renameSync(CRED_FILE + '.tmp', CRED_FILE);
  const mine = req.headers['x-token'];
  for (const t of sessions.keys()) if (t !== mine) sessions.delete(t); // sign out every other session
  res.json({ ok: true });
});

app.get('/api/admin/movies', auth, (req, res) => res.json(load().map(pub)));

app.patch('/api/movies/:id', auth, (req, res) => {
  const all = load();
  const m = all.find((x) => x.id === req.params.id);
  if (!m) return res.status(404).json({ error: 'Movie not found' });
  if (typeof req.body.hid === 'boolean') m.hid = req.body.hid;
  if (typeof req.body.feat === 'boolean') m.feat = req.body.feat;
  save(all);
  res.json(pub(m));
});

app.post('/api/movies', auth, takeUpload, (req, res) => {
  try {
    const m = { id: rid(), ...parse(req.body), n: 0, hue: Math.floor(Math.random() * 360), poster: '', files: {} };
    if (m.trailer && hasT(req)) throw new Error('Use either a trailer link or a trailer video, not both');
    const oldp = applyFiles(m, req);
    fixTrailer(m, req, false, oldp);
    applyShots(m, req, shotSpec(req));
    finishType(m, req, oldp, 'Add at least one movie file');
    const all = load();
    all.unshift(m);
    save(all);
    oldp.forEach(([dir, name]) => rm(dir, name));
    res.json(pub(m));
  } catch (e) {
    dropFiles(req);
    res.status(400).json({ error: e.message });
  }
});

app.put('/api/movies/:id', auth, takeUpload, (req, res) => {
  const all = load();
  const m = all.find((x) => x.id === req.params.id);
  if (!m) { dropFiles(req); return res.status(404).json({ error: 'Movie not found' }); }
  try {
    const keep = new Set([m.poster, ...m.c.map((c) => c.p)]);
    const parsed = parse(req.body);
    if (parsed.trailer && hasT(req)) throw new Error('Use either a trailer link or a trailer video, not both');
    Object.assign(m, parsed);
    // cast photos not re-sent keep their old image only if they were a real kept path
    const oldImgs = [...keep].filter(Boolean);
    const old = applyFiles(m, req);
    fixTrailer(m, req, rmFlag(req), old);
    old.push(...applyShots(m, req, shotSpec(req)));
    finishType(m, req, old, 'A movie needs at least one file');
    save(all);
    old.forEach(([dir, name]) => rm(dir, name));
    const now = new Set([m.poster, ...m.c.map((c) => c.p)]);
    oldImgs.filter((p) => !now.has(p)).forEach((p) => rm(IMG, p));
    res.json(pub(m));
  } catch (e) {
    dropFiles(req);
    res.status(400).json({ error: e.message });
  }
});

app.delete('/api/movies/:id', auth, (req, res) => {
  const all = load();
  const m = all.find((x) => x.id === req.params.id);
  if (!m) return res.status(404).json({ error: 'Movie not found' });
  Object.values(m.files).forEach((f) => rm(VID, f.file));
  (m.seasons || []).forEach((s) => s.eps.forEach((e) => epFiles(e).forEach((f) => rm(VID, f.file))));
  if (m.tvideo) rm(VID, m.tvideo.file);
  rm(IMG, m.poster);
  (m.shots || []).forEach((p) => rm(IMG, p));
  m.c.forEach((c) => rm(IMG, c.p));
  save(all.filter((x) => x.id !== m.id));
  res.json({ ok: true });
});

app.get('/download/:id/:q', (req, res) => {
  const all = load();
  const m = all.find((x) => x.id === req.params.id);
  const f = m && !m.hid && !m.soon && m.files[req.params.q]; // no downloads while Coming Soon
  if (!f) return res.status(404).send('File not found');
  m.n++;
  save(all);
  const name = (m.t + ' ' + req.params.q).replace(/[^\w .()-]/g, '_') + f.ext;
  res.download(path.join(VID, f.file), name, { dotfiles: 'allow' });
});

app.get('/download/:id/:ep/:q', (req, res) => {
  const all = load();
  const m = all.find((x) => x.id === req.params.id);
  if (!m || m.hid || m.soon) return res.status(404).send('File not found');
  let found = null;
  (m.seasons || []).forEach((s) => s.eps.forEach((e, k) => { if (e.id === req.params.ep) found = { e, s: s.n, k: k + 1 }; }));
  const f = found && found.e.files[req.params.q];
  if (!f) return res.status(404).send('File not found');
  m.n++;
  save(all);
  const name = (m.t + ' S' + found.s + 'E' + found.k + ' ' + req.params.q).replace(/[^\w .()-]/g, '_') + f.ext;
  res.download(path.join(VID, f.file), name, { dotfiles: 'allow' });
});

app.get('/trailer/:id', (req, res) => {
  const m = load().find((x) => x.id === req.params.id);
  if (!m || m.hid || !m.tvideo) return res.status(404).send('Trailer not found');
  res.sendFile(path.join(VID, m.tvideo.file), { dotfiles: 'allow' }); // supports seeking (Range requests)
});

// ---------- backups: a daily copy of the movie list and settings ----------
// Movie files and images are far too big to copy every day on the same disk, so they are not inside
// the backup (see DEPLOY.md). The backup holds everything that describes the site.
const BK_DIR = path.join(DATA, 'backups');
fs.mkdirSync(BK_DIR, { recursive: true });
const BK_KEEP = 30; // newest backups kept
const BK_NAME = /^backup-[\d-]+(-manual)?\.json$/;
const pad2 = (n) => String(n).padStart(2, '0');
const stamp = (d = new Date()) => d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
function snapshot() {
  const movies = load();
  const requests = loadReq();
  return {
    app: 'movie-world',
    version: 1,
    createdAt: new Date().toISOString(),
    note: 'Movie list and settings only. Movie files and images stay in the movies and images folders.',
    counts: { movies: movies.length, requests: requests.length },
    movies,
    categories: loadCats(),
    requests,
    announcement: ann,
  };
}
function listBackups() {
  return fs.readdirSync(BK_DIR).filter((n) => BK_NAME.test(n)).map((n) => {
    const st = fs.statSync(path.join(BK_DIR, n));
    return { name: n, size: st.size, mtime: st.mtimeMs, auto: !n.endsWith('-manual.json') };
  }).sort((a, b) => b.mtime - a.mtime);
}
function writeBackup(name) {
  const file = path.join(BK_DIR, name);
  fs.writeFileSync(file + '.tmp', JSON.stringify(snapshot(), null, 2));
  fs.renameSync(file + '.tmp', file);
  listBackups().slice(BK_KEEP).forEach((b) => fs.unlink(path.join(BK_DIR, b.name), () => {}));
}
function dailyBackup() {
  try {
    const name = 'backup-' + stamp() + '.json';
    if (!fs.existsSync(path.join(BK_DIR, name))) writeBackup(name);
  } catch (e) { console.error('Backup failed:', e.message); }
}
dailyBackup(); // on start, and then once every hour it checks whether today's backup exists
setInterval(dailyBackup, 60 * 60e3).unref();

app.get('/api/admin/backups', auth, (req, res) => res.json(listBackups()));

app.post('/api/admin/backups', auth, (req, res) => {
  const d = new Date();
  try { writeBackup('backup-' + stamp(d) + '-' + pad2(d.getHours()) + pad2(d.getMinutes()) + '-manual.json'); }
  catch (e) { return res.status(500).json({ error: 'Could not write the backup' }); }
  res.json(listBackups());
});

app.get('/api/admin/backups/:name', auth, (req, res) => {
  const n = req.params.name;
  if (!BK_NAME.test(n) || !fs.existsSync(path.join(BK_DIR, n))) return res.status(404).json({ error: 'Backup not found' });
  res.download(path.join(BK_DIR, n), n, { dotfiles: 'allow' });
});

app.get('/api/admin/backup', auth, (req, res) => { // a fresh backup, downloaded right now
  res.set('Content-Type', 'application/json');
  res.set('Content-Disposition', 'attachment; filename="movie-world-backup-' + stamp() + '.json"');
  res.send(JSON.stringify(snapshot(), null, 2));
});

app.listen(PORT, () => console.log('Movie World running on http://localhost:' + PORT + '\nData folder: ' + DATA + '\nAdmin login page (keep private): http://localhost:' + PORT + '/' + ADMIN_PATH));
